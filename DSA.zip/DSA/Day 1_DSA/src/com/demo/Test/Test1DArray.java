package com.demo.Test;

import java.util.stream.IntStream;

import com.demo.Array.MyArray;

public class Test1DArray {

	public static void main(String[] args) {
		MyArray marr= new MyArray();
		System.out.println("The arrays are:" +marr. getArraylength());
		marr. addInEnd(6);
		marr. addInEnd(7);
		marr. addInEnd(4);
		marr. addInEnd(9);
		marr. addInEnd(8);
		System.out.println(marr.getElements());	
	
		System.out.println("The original array is:"+marr);
		
		
//		ob.reverseArray(true);
//		System.out.println("The reversed array is:"+marr);
//		
//		ob.rotateArray(false,2);
//		System.out.println("The  rotated array is" +marr);
//		
		
		int arr1[]=marr.exchangeIndexVal();
		IntStream.of(arr1).forEach(e->System.out.print(e+","));
		
//		ob.findSum();
//		System.out.println("The sum is:"+ob);
		
		
		int arr2[]=marr.findSum();
		IntStream.of(arr2).forEach(e->System.out.print(e+","));
		

	}

}
