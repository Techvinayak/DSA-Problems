 package com.demo.Array;

import java.util.Arrays;

public class MyArray {
	private int [] arr;
	private int count;
	
	//method 1
	public MyArray() {
		arr= new int [10];
		count=0;
	}

    
	public MyArray(int[] arr, int count) {
		this.arr = arr;
		this.count = count;
	}
	
	public int getArraylength() {
		return arr.length;
	}
	
	public int getElements() {
		return count;
	}
	
	
	//add at the end 
	public boolean addInEnd(int x) {
		if(count<arr.length) {
			arr[count]=x;
			count++;
			return true;
		}
		return false;
	}
       
	
	//add at the given pos
	
	public boolean add(int value,int pos) {
		if(count<arr.length && pos<count) {
			for(int i=0;i>pos;i--) {
				arr[i]=arr[i-1];
			}
			arr[pos]=value;
			count++;
			return true;
		}
		return false;
	}
	
	//search by value
	public int searchByValue(int value) {
		for (int i=0;i<count;i++) {
			if(arr[i]==value){
				return i;
			}
		}
		return -1;
	}
	
	//delete the value of specific position
	public boolean deleteByPos(int pos) {
		if (pos<count) {
			for(int i=pos;i<count-1;i++) {
				arr[i]=arr[i+1];
			}
			count--;
			return true;
		}
		return false;
	}
	
	//delete the value
	public boolean deleteByValue(int value) {
		int ind= searchByValue(value);
		if(ind!=-1) {
			return deleteByPos(ind);
		}
		return false;
	}
	
	//rotate Array
	public void rotateArray(boolean flag,int num) {
		if(flag) {
			for(int count=0;count<num;count++) {
				int temp =arr[count-1];
				for(int i=count-1;i>0;i--) {
					arr[i]=arr[i-1];
				}
				arr[0]=temp;
			}
			
		}
		else {
			for(int count=0;count<num;count++) {
				int firstval=arr[0];
				for(int i=0;i<count-1;i++) {
					arr[i]=arr[i+1];
				}
				arr[count-1]=firstval;
			}
			
		}
	}
	
	//if flag=true then reverse the array inplace
	//else reverse the cop of this array
	public int[]reverseArray(boolean flag){
		if(flag) {
			for(int i=0,j=count-1;i<j;i++,j--) {
				int temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
			return arr;
		}
		else {
			int []arr1 =new int[count];
			for(int i=count-1,j=0;i>0;i--,j++) {
				arr1[j]=arr[i];
				
			}
			return arr1;
		}
	}
	
	//replace index with values in the array
	
	public int [] exchangeIndexVal() {
		int max=findMax();
		int[] arr1= new int[max+1];
		for(int i=0;i<arr1.length;i++) {
			arr1[i]=-1;
		}
		for(int i=0;i<count;i++) {
			int idx=arr[i];
			int val=i;
			arr[idx]=val;
		}
		return arr1;
	}


	private int findMax() {
		int max=arr[0];
		for(int i=0;i<count;i++) {
			if(max<arr[i]) {
				max=arr[i];
			}
		
		}
		return max;
		
	}

	
	
	
	public int findSum() {
		int sum=0;
		for(int i=0;i<count;i++) {
			sum+=arr[i];
		}
		return sum;
		
	}

	@Override
	public String toString() {
		return "MyArray [arr=" + Arrays.toString(arr) + "]";
	}


	
	
	
	
	
	
	
}
