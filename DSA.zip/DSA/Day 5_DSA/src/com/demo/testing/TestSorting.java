package com.demo.testing;

import com.demo.sorting.*;
public class TestSorting {

	public static void main(String[] args) {
			int [] arr = {21,3,15,6,7,92,9,2,10,1};
			MergeSort.mergeSort(arr, 0, arr.length-1);
			
//			SelectionSort.SelectionSort(arr);
//			SelectionSort.SelectionSortDesc(arr);
			
	}

}

