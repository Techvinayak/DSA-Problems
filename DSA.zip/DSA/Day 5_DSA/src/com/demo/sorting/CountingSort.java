package com.demo.sorting;

import java.util.Arrays;

public class CountingSort {

	
	   public static int [] countSorting(int [] arr) {
		   
		   int max = Max(arr);
		   
		   int [] count = new int [max+1];
		   
		   for(int i=0;i<count.length;i++) {
			   count[i]=0;
		   }
		   
		   for(int i=0;i<arr.length;i++) {
			   int pos=arr[i];
			   count[pos]++;
		   }
		   
		   for(int i=1;i<count.length;i++) {
			   count[i]+=count[i-1];
		   }
		   
		   int [] result=new int [arr.length];
		   
		   for(int i=0;i<arr.length;i++) {
			   int pos= arr[i];
			   count[pos]--;
			   int idx=	count[pos];
			   result [idx]=arr[i];
		   }
		   
		   System.out.println(Arrays.toString(result));
		   return result;
	   }

	private static int Max(int[] arr) {
		int max= arr[0];
		for(int i=1;i<arr.length;i++) {
			if(max<arr[i]) {
				max=arr[i];
			}
		}
		return max;
	}
	   
	   
	   
	   
	   
	   
	   
}
