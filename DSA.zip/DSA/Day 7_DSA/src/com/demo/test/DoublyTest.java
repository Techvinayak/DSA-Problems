package com.demo.test;

public class DoublyTest {

	public static void main(String[] args) {
	

	}

}
