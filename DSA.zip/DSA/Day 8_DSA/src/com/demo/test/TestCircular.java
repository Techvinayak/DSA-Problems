package com.demo.test;
import com.demo.linkedlist.*;
public class TestCircular {

	public static void main(String[] args) {
		CircularLinkedList cl1 = new CircularLinkedList();
		cl1.addNode(10);
		cl1.addNode(20);
		cl1.addNode(11);
		cl1.addNode(1);
		cl1.display();
	}

}
