package com.demo.test;
import com.demo.queue.*;
public class TestCircularQueue {

	public static void main(String[] args) {
		CircularQueue cqueue=new CircularQueue(5);
		cqueue.enqueue(4);
		cqueue.enqueue(41);
		cqueue.enqueue(42);
		cqueue.enqueue(43);
		cqueue.enqueue(44);
		cqueue.enqueue(4); 
		System.out.println(cqueue.dequeue());
		System.out.println(cqueue.dequeue());
		cqueue.enqueue(421);
		cqueue.enqueue(431);
		cqueue.enqueue(422); 
		System.out.println(cqueue.dequeue());
		System.out.println(cqueue.dequeue());
		System.out.println(cqueue.dequeue());
		System.out.println(cqueue.dequeue());
		System.out.println(cqueue.dequeue());
		System.out.println(cqueue.dequeue());
	}

}
