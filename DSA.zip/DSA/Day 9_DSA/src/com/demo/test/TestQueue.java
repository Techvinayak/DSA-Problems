package com.demo.test;
import com.demo.stacksqueue.*;
public class TestQueue {

	public static void main(String[] args) {
		QueueList qlist=new QueueList();
		qlist.enqueue(12);
		qlist.enqueue(34);
		qlist.enqueue(3);
		qlist.enqueue(5);
		qlist.enqueue(16);
		System.out.println(qlist.dequeue());
		System.out.println(qlist.dequeue()); 
		System.out.println(qlist.dequeue());
		System.out.println(qlist.dequeue());
		System.out.println(qlist.dequeue());
		System.out.println(qlist.dequeue());

	}

}
