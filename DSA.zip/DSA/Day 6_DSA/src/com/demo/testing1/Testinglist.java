package com.demo.testing1;
import com.demo.linkedlist.*;
public class Testinglist {

	public static void main(String[] args) {
		SinglyLinkedList list1=new SinglyLinkedList();
	    list1.addByEnd(10);
	    list1.addByEnd(20);
	    list1.addByEnd(30);
	    list1.addByEnd(40);
	    list1.display();
//	    list1.addByValue(50, 40);
//	    list1.display();
	    list1.addByPos(3,80 );
	    list1.display();
	}

}
