package com.demo.test;

import com.demo.sorting.HeapSort;

public class TestSorting {

	public static void main(String[] args) {
		int [] arr= {3,7,5,10,9,8,4};
		
		HeapSort.heapSort(arr);

	}

}
