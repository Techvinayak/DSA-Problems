package com.demo.array;

public class Sorting {

	public static int sequentialSearch(int []arr, int search ) {
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==search) {
				return i;
			}
		}
		return -1;
	}


	public static int binarySearchNonRecurssive(int [] arr, int search) {
		int low=0;
		int high=arr.length-1;
		int cnt=0;
		while(low<=high) {
			int mid=(low+high)/2;
			cnt++;
			for(int i=0;i<arr.length;i++) {
				if(arr[i]==mid) {
					System.out.println("The no. of comparison occured were:"+cnt);
					return mid;
				}
			   if(search<high) {
				   high=mid-1;
			   }
			   else {
				   low=mid+1;
			   }
			}
		}
		System.out.println("The no. of comparison were:"+cnt);
		return -1;
	
	}
	public static int binarySearchRecurssive(int [] arr, int search, int high , int low) {
		if(low<=high) {
			int mid=(low+high)/2;
			if(arr[mid]==search) {
				return mid;
			}
			else if(search<arr[mid]) {
				return binarySearchRecurssive(arr,search,low,mid-1);
			}
			else {
				return binarySearchRecurssive(arr,search,high,mid+1);
			}
		}
		return -1;
	}














}