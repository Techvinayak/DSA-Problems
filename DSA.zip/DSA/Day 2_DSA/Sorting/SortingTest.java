package com.demo.test;

import com.demo.array.Sorting;
public class SortingTest {

	public static void main(String[] args) {
		int[] arr= {10,5,4,7,8,3,2,15};
		
		int pos=Sorting.sequentialSearch(arr,7);
		if(pos!=-1) {
			System.out.println("number found at position : "+pos);
		}else {
			System.out.println("not found");
		}
		
		int[] arr1= {12,22,45,32,99,100,1001,24,10,11};
		pos=Sorting.binarySearchNonRecurssive(arr1,1001);
		if(pos!=-1) {
			System.out.println("binary search number found at position : "+pos);
		}else {
			System.out.println("binary search number not found");
		}
		
		pos=Sorting.binarySearchRecurssive(arr1,12,0,10);
		if(pos!=-1) {
			System.out.println("binary search number found at position : "+pos);
		}else {
			System.out.println("binary search number not found");
		}

	}

}
