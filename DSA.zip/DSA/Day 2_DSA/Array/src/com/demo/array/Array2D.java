package com.demo.array;
import java.util.Scanner;

public class Array2D {

	private int [][] arr;
	
	public Array2D(){
		arr=new int[3][3];
	}
	
	public Array2D(int rows,int cols) {
		arr = new int[rows][cols];
	}
	
	//accept data in array
	public void acceptData() {
		Scanner sc= new Scanner(System.in);
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
				System.out.println("Enter value for i: "+i+ "j:"+j);
				 arr[i][j]= sc.nextInt();
			}
		}
	}
	
	//display data in array
	public void displayData(){
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
		        System.out.println(arr[i][j]+ "\t");		
			}
			System.out.println();
		}
	
	}
	
	//find addition row wise
	public int[]findSumrowise(){
		int sum[] = new int[arr.length];
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
				sum[i]+=arr[i][j];
			}
		}
		return sum;	
	}
	
	//find addition columnwise
	public int [] findSumcols(){
		int sum[]= new int[arr[0].length];
		for(int i=0;i<arr[0].length;i++) {
			for(int j=0;j<arr.length;j++) {
				sum[i]+=arr[j][i];
			}
		}
		return sum;
	}
	
	//addition of 2 matrices
	public int [] []addition2matrix(Array2D ob) {
		if(this.arr.length==ob.arr.length && this.arr[0].length==ob.arr[0].length) {
			int [][]temp= new int [arr.length][arr[0].length];
			
			for(int i=0;i<this.arr.length;i++) {
				for(int j=0;j<this.arr[0].length;j++) {
					temp [i][j]=this.arr[i][j]+ob.arr[i][j];
				}
			}
		}
		return arr;
	}
	
	//Subtraction of 2 matrices
		public int [] []subtraction2matrix(Array2D ob) {
			if(this.arr.length==ob.arr.length && this.arr[0].length==ob.arr[0].length) {
				int [][]temp= new int [arr.length][arr[0].length];
				
				for(int i=0;i<this.arr.length;i++) {
					for(int j=0;j<this.arr[0].length;j++) {
						temp [i][j]=this.arr[i][j]-ob.arr[i][j];
					}
				}
			}
			return arr;
		}
	
		
		//if flag is true rotate upward
		//if flag is false rotate downward
		public void RotateRow(boolean flag , int num) {
			if(flag) {
				for(int count=0;count<num;count++) {
					int [] temp= arr[0];
					for(int i=0;i<arr.length-1;i++) {
						arr[i]=arr[i+1];
					}
					arr[arr.length-1]=temp;
					
				}
			}
			else {
				for(int count=0;count<num;count++) {
					int [] temp =arr[arr.length-1];
					for(int i=arr.length-1;i>0;i--) {
						arr[i]=arr[i-1];
					}
					arr[0]=temp;
				}
			}
		}
		
		
		//if flag is true rotate right
		//if flag is false rotate left
		
		public void RotateCols(boolean flag, int num) {
			  if(flag) {
				  for(int count=0;count<num;count++) {
						int []temp=new int [arr.length];
						for(int i=0;i<arr.length;i++) {
							temp[i]=arr[i][arr[0].length-1];
						}
						for(int i=0;i<arr.length;i++) {
							for(int j=arr[0].length-2;j>=0;j--) {
								arr[i][j+1]=arr[i][j];
							}
						}
					 for(int i=0;i<arr.length;i++) {
						 arr[i][0]=temp[i];
					 	}
					}
				  	 
			  }
			  else {
				  for(int count=0;count<num;count++) {
					  int []temp=new int [arr.length];
					  for(int i=0;i<arr.length;i++) {
						 temp[i]=arr[i][0];
					  }
					  for(int i=0;i<arr.length;i++) {
							for(int j=1;j<arr[0].length;j++) {
								arr[i][j+1]=arr[i][j];
							}
						}
					  for(int i=0;i<arr.length;i++) {
							arr[i][arr[0].length-1]=temp[i];
						}
				  }
			  }
			
		}
		
	//transpose of matrix
	public int [][]transpose(){
		int [][] temp= new int [arr.length][arr[0].length];
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
				temp[j][i]= arr[i][j];
			}
		}
		return temp;
	}
	
	
	//identity matrix 
	public boolean isIdentity(){
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
				if(i==j && arr[i][j]!=1) {
					return false;
				}
				else if(i!=j && arr[i][j]!=0) {
					return false;
				}
			}
		}
		return true;

	}
		
	
	//Symmetric matrix
	public boolean isSymmetric() {
		if(arr.length==arr[0].length) {
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[0].length;j++) {
				if(i==j && arr[i][j]!=1) {
					return false;
				}
				else if(i!=j && arr[i][j]!=0) {
					return false;
				}
			}
			return true;
			}
		   
		}
		return false;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}
