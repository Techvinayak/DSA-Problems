package com.demo.sorting;

import java.util.Arrays;

public class Insertion_Sort {
		public static void insertionSort (int []arr) {
			for(int i=0;i<arr.length;i++) {
				int j=i-1;
				int key =arr[i];
				
				if(j>=0 && arr[j]>key) {
					arr[i+1]=arr[j];
					j--;
				}
				arr[j+1]=key;
				System.out.println(Arrays.toString(arr));
			}
		}
		
		
		
		
		public static void insertiondesc(int []arr) {
			for(int i=0;i<arr.length;i++) {
				int j=i-1;
				int key =arr[i];
				
				if(j>=0 && arr[j]<key) {
					arr[i+1]=arr[j];
					j--;
				}
				arr[j+1]=key;
				System.out.println(Arrays.toString(arr));
			}
		}
}
