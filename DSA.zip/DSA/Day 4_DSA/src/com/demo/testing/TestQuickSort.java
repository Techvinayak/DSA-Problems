package com.demo.testing;

import com.demo.sorting.Quick_Sort;

public class TestQuickSort {

	public static void main(String[] args) {
		int [] arr= {15,22,48,92,21,34,2,18,54,67 };
		Quick_Sort.quicksort(arr, 0, arr.length-1);		

	}

}
