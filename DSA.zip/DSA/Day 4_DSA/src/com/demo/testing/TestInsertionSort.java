package com.demo.testing;

import com.demo.sorting.Insertion_Sort;

public class TestInsertionSort {

	public static void main(String[] args) {
	     int [] arr = {92,22,78,32,22,10,9,20,2,49};
	     Insertion_Sort.insertionSort(arr);
//	     Insertion_Sort.insertiondesc(arr);
	}

}
