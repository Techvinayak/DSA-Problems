package com.demo.test;

import com.demo.list.*; 

import java.util.Scanner;

public class TestAdjsencyList {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("How many vertices?");
		int v=sc.nextInt();	
		Graph g=new Graph(v);
		storeGraph(g,v);
		g.printGraph();
		g.dfsTraversal(0);
		g.bfsTraversal(0);
		
	}

	private static void storeGraph(Graph g,int v) {
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<v;i++) {
			for(int j=0;j<v;j++) {
				System.out.println("Is there a edge between "+i+"----"+j);
				int val=sc.nextInt();
				
				if(val>0) {
					g.addEdge(i, j);
					
				}
				
			}
		}
		
	}


	}


