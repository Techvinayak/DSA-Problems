package com.demo.list;

import com.demo.stack.*;

import com.demo.list.*;

public class Graph {
	
	LinkedList [] graph;
	public Graph (int v) {
		this.graph=new LinkedList[v];
	for(int i=0;i<this.graph.length;i++) {
		graph[i]=new LinkedList();
	}
	}
	
	public void addEdge(int source,int dest) {
		graph[source].addNode(dest);
	}
	
	public void printGraph() {
		for(int i=0;i<graph.length;i++) {
			System.out.println(i+"==>");
			graph[i].displayList();
		}
	}
	
	public void dfsTraversal(int start) {
		System.out.println("DFS traversal");
		boolean [] visited = new boolean [graph.length];
		for(int i=0;i<graph.length;i++) {
			visited [i]=false;
		}
		StackGenericList<Integer> st = new StackGenericList<Integer>();
		st.push(start);
		String dfs="";
		while(!st.isEmpty()) {
			int v=st.pop();
			if(!visited[v]) {
				dfs +=v+",";
				visited[v]=true;
				int [] arr= new int [graph.length];
				for(int i=0;i<graph.length;i++) {
					arr[i]=-1;
				}
				graph[v].getAdjescentNode(arr);
				for(int i=0;i<graph.length;i++) {
					if(arr[i]!=-1 && !visited[arr[i]]) {
						st.push(arr[i]);
					}
				}
			}
			System.out.println(dfs);
		}
	}
	
	
	public void bfsTraversal(int start) {
		System.out.println("bfsTravel");
		boolean []visited=new boolean [graph.length];
		for(int i=0;i<graph.length;i++) {
			visited[i]=false;
		}
		QueueList que = new QueueList();
		que.enQueue(start);
		String bfs=" ";
		while(!que.isEmpty()) {
			int v=que.dequeue();
			if(!visited[v]) {
				bfs+=v+",";
				visited[v]=true;
				int []arr=new int[graph.length];
				for(int i=0;i<graph.length;i++) {
					arr[i]=-1;
				}
				graph[v].getAdjescentNode(arr);
				for(int i=0;i<graph.length;i++) {
					if(arr[i]!=-1 && !visited[arr[i]]) {
						que.enQueue(arr[i]);
					}
				};
			}
			System.out.println(bfs);
	}
	
	
	}
	
	
}
